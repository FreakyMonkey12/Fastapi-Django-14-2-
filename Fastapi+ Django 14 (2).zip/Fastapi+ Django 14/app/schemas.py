from pydantic import BaseModel
from datetime import datetime

class UserCreate(BaseModel):
    email: str
    password: str

class User(BaseModel):
    id: int
    email: str
    is_active: bool

    class Config:
        orm_mode = True

class ContactCreate(BaseModel):
    name: str
    surname: str
    email: str
    phone: str
    birthday: datetime
    additional_data: str = None

class Contact(BaseModel):
    id: int
    name: str
    surname: str
    email: str
    phone: str
    birthday: datetime
    additional_data: str
    owner_id: int

    class Config:
        orm_mode = True
