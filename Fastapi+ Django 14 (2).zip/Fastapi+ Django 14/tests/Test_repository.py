# app/tests/test_repositories.py

import pytest
from app import models, crud
from app.database import SessionLocal

@pytest.fixture
def db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def test_create_user(db):
    user = crud.create_user(db, email="test@example.com", password="password")
    assert user.email == "test@example.com"
    assert user.password != "password"  # пароль должен быть захеширован
